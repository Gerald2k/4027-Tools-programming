﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GridEditor
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// private int GridWidth = 5;

    public partial class MainWindow : Window
    {
        private bool penIsDown = false;
        private int GridHeight = 5;
        private int GridWidth = 5;
        private ImageSource penImageSource;
        private Image[,] images;

        private Tool selectedTool = Tool.Pen;
        public MainWindow()
        {
            penImageSource = new BitmapImage(new Uri("N:/My Documents/CT4027 - C# Tools/SingleTileSamples/dirt.png"));
            InitializeComponent();

            images = new Image[GridWidth, GridHeight];

            for (int x = 0; x < GridWidth; x++)
            {
                for (int y = 0; y < GridHeight; y++)
                {

                    Image image = new Image();
                    Grid.SetColumn(image, x);
                    Grid.SetRow(image, y);

                    grid.Children.Add(image);

                    images[x, y] = image;
                }
            }
            grid.MouseDown += OnMouseDown;
            grid.MouseUp += OnMouseUp;
            grid.MouseMove += OnMouseMove;
        }

        private void OnMouseDown(object sender, MouseButtonEventArgs e)
        {
            penIsDown = true;
        }
        private void OnMouseUp(object sender, MouseButtonEventArgs e)
        {
            penIsDown = false;
        }
        private void OnMouseMove(object sender, MouseEventArgs e)
        {
            if (penIsDown) {
                int x = (int)e.GetPosition(grid).X / 32;
                int y = (int)e.GetPosition(grid).Y / 32;
                UseTool(x, y);
            }
        }
        private void OnMouseLeave(object sender, MouseButtonEventArgs e)
        {
            penIsDown = false;
        }

        private void UseTool(int gridX, int gridY)
        {
            switch (selectedTool)
            {
                case Tool.Pen:
                    if (gridX < 5 && gridY < 5) {
                        images[gridX, gridY].Source = penImageSource;
                    }
                    break;

                case Tool.Erase:
                    if (gridX < 5 && gridY < 5) {
                        images[gridX, gridY].Source = null;
                    }
                    break;
            }
        }

        private void HandleNew(object sender, RoutedEventArgs e)
        {
            for (int x = 0; x < GridWidth; x++)
            {
                for (int y = 0; y < GridHeight; y++)
                {

                    Image image = new Image();
                    Grid.SetColumn(image, x);
                    Grid.SetRow(image, y);

                    grid.Children.Add(image);

                    images[x, y].Source = null;
                    selectedTool = Tool.Pen;
                }
            }
        }

        private void HandleClose(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void HandlePen(object sender, RoutedEventArgs e)
        {

        }
        private void HandleErase(object sender, RoutedEventArgs e)
        {
            selectedTool = Tool.Erase;
        }
        public enum Tool
        {
            Pen,
            Erase
        }
    }
}



